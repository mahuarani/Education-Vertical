# Welcome Week 2021-2024


```python
import pandas as pd 
import numpy as np 
import matplotlib.pyplot as plt
```


```python
file_paths = {
    "Fall 2021": "C:/Users/MahuaNitin.Hiray001/Desktop/Welcome Week/Fall21.csv",
    "Spring 2022": "C:/Users/MahuaNitin.Hiray001/Desktop/Welcome Week/Spring22.csv",
    "Fall 2022": "C:/Users/MahuaNitin.Hiray001/Desktop/Welcome Week/Fall22.csv",
    "Fall 2023": "C:/Users/MahuaNitin.Hiray001/Desktop/Welcome Week/Fall23.csv",
    "Fall 2024": "C:/Users/MahuaNitin.Hiray001/Desktop/Welcome Week/Fall24.csv"
}

# Initialize an empty dictionary to store dataframes
survey_data = {}

# Load the CSV files into pandas DataFrames
for key, path in file_paths.items():
    survey_data[key] = pd.read_csv(path)

# Display a preview of the data to identify structure
survey_previews = {key: df.head() for key, df in survey_data.items()}
survey_previews
```




    {'Fall 2021':    RespondentId Satellite  ExternalId  Email          DateTime  CardData  \
     0      93078391    umbweb         NaN    NaN  10/20/2021 12:26       NaN   
     1      93078392    umbweb         NaN    NaN  10/20/2021 12:26       NaN   
     2      93078394    umbweb         NaN    NaN  10/20/2021 12:26       NaN   
     3      93078395    umbweb         NaN    NaN  10/20/2021 12:26       NaN   
     4      93078396    umbweb         NaN    NaN  10/20/2021 12:26       NaN   
     
        Q1. Classification:  Q2. Are you an International Student?  \
     0                  NaN                                    NaN   
     1                  4.0                                    2.0   
     2                  NaN                                    NaN   
     3                  NaN                                    NaN   
     4                  2.0                                    2.0   
     
        Q3. Where do you reside?  Q4. Did you attend any Welcome Week Events?  ...  \
     0                       NaN                                          NaN  ...   
     1                       3.0                                          2.0  ...   
     2                       NaN                                          NaN  ...   
     3                       NaN                                          NaN  ...   
     4                       2.0                                          2.0  ...   
     
       Q23_4:6pm - 9pm Q24_1:9am - 12pm Q24_2:12pm - 3pm Q24_3:3pm - 6pm  \
     0              --               --               --              --   
     1              --               --               --              --   
     2              --               --               --              --   
     3              --               --               --              --   
     4             NaN              NaN                2             NaN   
     
       Q24_4:6pm - 9pm  \
     0              --   
     1              --   
     2              --   
     3              --   
     4             NaN   
     
       Q25. Have you purchased tickets using the UMB Ticket system?  \
     0                                                NaN             
     1                                                2.0             
     2                                                NaN             
     3                                                NaN             
     4                                                2.0             
     
       Q26. Please indicate your level of agreement with the following: - I found the new ticket system to be easy to use.  \
     0                                                NaN                                                                    
     1                                                NaN                                                                    
     2                                                NaN                                                                    
     3                                                NaN                                                                    
     4                                                NaN                                                                    
     
       Q27. Please indicate your level of agreement with the following: - I was able to successfully purchase ticket using the new ticket system  \
     0                                                NaN                                                                                          
     1                                                NaN                                                                                          
     2                                                NaN                                                                                          
     3                                                NaN                                                                                          
     4                                                NaN                                                                                          
     
       Q28. Which tickets would you like for us to start selling in the Student Activities Office?  \
     0                                                NaN                                            
     1                                                NaN                                            
     2                                                NaN                                            
     3                                                NaN                                            
     4                                                1.0                                            
     
           Q28_1OT  
     0         NaN  
     1         NaN  
     2         NaN  
     3         NaN  
     4  Concerts    
     
     [5 rows x 67 columns],
     'Spring 2022':    RespondentId      Satellite  ExternalId  Email         DateTime  CardData  \
     0      94060247  uom-b-default         NaN    NaN  2/11/2022 13:05       NaN   
     1      94060248  uom-b-default         NaN    NaN  2/11/2022 13:05       NaN   
     2      94060250  uom-b-default         NaN    NaN  2/11/2022 13:05       NaN   
     3      94060251  uom-b-default         NaN    NaN  2/11/2022 13:05       NaN   
     4      94060252  uom-b-default         NaN    NaN  2/11/2022 13:05       NaN   
     
        Q1. Classification:  Q2. Are you an International Student?  \
     0                  NaN                                    NaN   
     1                  3.0                                    2.0   
     2                  NaN                                    NaN   
     3                  1.0                                    2.0   
     4                  NaN                                    NaN   
     
        Q3. Where do you reside?  Q4. Did you attend any Welcome Week Events?  ...  \
     0                       NaN                                          NaN  ...   
     1                       3.0                                          2.0  ...   
     2                       NaN                                          NaN  ...   
     3                       2.0                                          2.0  ...   
     4                       NaN                                          NaN  ...   
     
       Q22_4:6pm - 9pm Q23_1:9am - 12pm Q23_2:12pm - 3pm Q23_3:3pm - 6pm  \
     0              --               --               --              --   
     1               4              NaN              NaN               3   
     2              --               --               --              --   
     3             NaN                1              NaN             NaN   
     4              --               --               --              --   
     
       Q23_4:6pm - 9pm  \
     0              --   
     1               4   
     2              --   
     3             NaN   
     4              --   
     
       Q24. Have you purchased tickets using the UMB Ticket system?  \
     0                                                NaN             
     1                                                1.0             
     2                                                NaN             
     3                                                2.0             
     4                                                NaN             
     
       Q25. Please indicate your level of agreement with the following: - I found the new ticket system to be easy to use.  \
     0                                                NaN                                                                    
     1                                                3.0                                                                    
     2                                                NaN                                                                    
     3                                                NaN                                                                    
     4                                                NaN                                                                    
     
       Q26. Please indicate your level of agreement with the following: - I was able to successfully purchase ticket using the new ticket system  \
     0                                                NaN                                                                                          
     1                                                3.0                                                                                          
     2                                                NaN                                                                                          
     3                                                NaN                                                                                          
     4                                                NaN                                                                                          
     
       Q27. Which tickets would you like for us to start selling in the Student Activities Office?  \
     0                                                NaN                                            
     1                                                1.0                                            
     2                                                NaN                                            
     3                                                1.0                                            
     4                                                NaN                                            
     
         Q27_1OT  
     0       NaN  
     1   Tickets  
     2       NaN  
     3  Patriots  
     4       NaN  
     
     [5 rows x 60 columns],
     'Fall 2022':    RespondentId      Satellite  ExternalId  Email         DateTime  CardData  \
     0      95393679  uom-b-default         NaN    NaN  9/23/2022 16:10       NaN   
     1      95393680  uom-b-default         NaN    NaN  9/23/2022 16:10       NaN   
     2      95393681  uom-b-default         NaN    NaN  9/23/2022 16:10       NaN   
     3      95393682  uom-b-default         NaN    NaN  9/23/2022 16:10       NaN   
     4      95393683  uom-b-default         NaN    NaN  9/23/2022 16:10       NaN   
     
        Q1. Classification:  \
     0                  NaN   
     1                  2.0   
     2                  NaN   
     3                  4.0   
     4                  NaN   
     
        Q2. Did you ever transfer to Umass Boston at any point? Q2_1OT  \
     0                                                NaN          NaN   
     1                                                1.0           No   
     2                                                NaN          NaN   
     3                                                1.0           NO   
     4                                                NaN          NaN   
     
        Q3. Are you an International Student?  ...  Q24_1:9am - 12pm  \
     0                                    NaN  ...                --   
     1                                    1.0  ...                 1   
     2                                    NaN  ...                --   
     3                                    1.0  ...                --   
     4                                    NaN  ...                --   
     
        Q24_2:12pm - 3pm Q24_3:3pm - 6pm Q24_4:6pm - 9pm Q25_1:9am - 12pm  \
     0                --              --              --               --   
     1               NaN             NaN             NaN              NaN   
     2                --              --              --               --   
     3                --              --              --               --   
     4                --              --              --               --   
     
       Q25_2:12pm - 3pm Q25_3:3pm - 6pm Q25_4:6pm - 9pm  \
     0               --              --              --   
     1                2               3               4   
     2               --              --              --   
     3               --              --              --   
     4               --              --              --   
     
       Q26. Which tickets would you like for us to start selling in the Student Activities Office?  \
     0                                                NaN                                            
     1                                                NaN                                            
     2                                                NaN                                            
     3                                                1.0                                            
     4                                                NaN                                            
     
            Q26_1OT  
     0          NaN  
     1          NaN  
     2          NaN  
     3  NFL and NBA  
     4          NaN  
     
     [5 rows x 78 columns],
     'Fall 2023':    RespondentId Satellite  ExternalId  Email         DateTime  CardData  \
     0      98323698    umbweb         NaN    NaN  12/12/2023 8:55       NaN   
     1      98323705    umbweb         NaN    NaN  12/12/2023 8:59       NaN   
     2      98323706    umbweb         NaN    NaN  12/12/2023 8:59       NaN   
     3      98323708    umbweb         NaN    NaN  12/12/2023 9:01       NaN   
     4      98323709    umbweb         NaN    NaN  12/12/2023 9:01       NaN   
     
        Q1. Classification:  \
     0                  NaN   
     1                  NaN   
     2                  1.0   
     3                  NaN   
     4                  3.0   
     
        Q2. Did you, at any point, transfer from another university/college to UMass Boston?  \
     0                                                NaN                                      
     1                                                NaN                                      
     2                                                2.0                                      
     3                                                NaN                                      
     4                                                2.0                                      
     
        Q3. Are you an International Student?  Q4. Where do you reside?  ...  \
     0                                    NaN                       NaN  ...   
     1                                    NaN                       NaN  ...   
     2                                    2.0                       1.0  ...   
     3                                    NaN                       NaN  ...   
     4                                    2.0                       2.0  ...   
     
       Q19_8:Food Trucks Q19_9:Casino Nights Q19_10:Board Game Events  \
     0                --                  --                       --   
     1                --                  --                       --   
     2                --                  --                       --   
     3                --                  --                       --   
     4                --                  --                       --   
     
       Q19_11:Movie Nights Q19_12:Open Mic/Talent Shows Q19_13:Paint Nights  \
     0                  --                           --                  --   
     1                  --                           --                  --   
     2                  --                           --                  --   
     3                  --                           --                  --   
     4                  --                           --                  --   
     
       Q19_14:Other  Q20. What times do you prefer for attending events on campus?  \
     0           --                                                NaN               
     1           --                                                NaN               
     2           --                                                1.0               
     3           --                                                NaN               
     4           --                                                3.0               
     
       Q21. Which activities in Boston would you like Student Activities to sell event tickets to?  \
     0                                                NaN                                            
     1                                                NaN                                            
     2                                                NaN                                            
     3                                                NaN                                            
     4                                                1.0                                            
     
                 Q21_1OT  
     0               NaN  
     1               NaN  
     2               NaN  
     3               NaN  
     4  red sox, museums  
     
     [5 rows x 64 columns],
     'Fall 2024':                                            StartDate  \
     0                                         Start Date   
     1  {"ImportId":"startDate","timeZone":"America/Ne...   
     2                                2024-10-31 16:16:43   
     3                                2024-11-01 10:54:17   
     4                                2024-11-01 10:56:36   
     
                                                  EndDate                 Status  \
     0                                           End Date          Response Type   
     1  {"ImportId":"endDate","timeZone":"America/New_...  {"ImportId":"status"}   
     2                                2024-10-31 16:17:07         Survey Preview   
     3                                2024-11-01 10:56:16             IP Address   
     4                                2024-11-01 11:00:14             IP Address   
     
                       IPAddress                 Progress    Duration (in seconds)  \
     0                IP Address                 Progress    Duration (in seconds)   
     1  {"ImportId":"ipAddress"}  {"ImportId":"progress"}  {"ImportId":"duration"}   
     2                       NaN                      100                       24   
     3            158.121.180.36                      100                      118   
     4            73.186.223.126                      100                      217   
     
                       Finished                                       RecordedDate  \
     0                 Finished                                      Recorded Date   
     1  {"ImportId":"finished"}  {"ImportId":"recordedDate","timeZone":"America...   
     2                     True                                2024-10-31 16:17:08   
     3                     True                                2024-11-01 10:56:16   
     4                     True                                2024-11-01 11:00:15   
     
                      ResponseId                 RecipientLastName  ...  \
     0               Response ID               Recipient Last Name  ...   
     1  {"ImportId":"_recordId"}  {"ImportId":"recipientLastName"}  ...   
     2         R_3P0SIZXatPj0sFw                               NaN  ...   
     3         R_6TVPnZKZg3i54Tn                               NaN  ...   
     4         R_1r2Lu1mnayAiB2h                               NaN  ...   
     
                                                    Q12_2  \
     0  Q12. Were there any specific barriers that pre...   
     1                 {"ImportId":"QID5","choiceId":"2"}   
     2                                                NaN   
     3                                                NaN   
     4                                                NaN   
     
                                                    Q12_7  \
     0  Q12. Were there any specific barriers that pre...   
     1                 {"ImportId":"QID5","choiceId":"7"}   
     2                                                NaN   
     3                                                NaN   
     4                                                NaN   
     
                                                    Q12_9  \
     0  Q12. Were there any specific barriers that pre...   
     1                 {"ImportId":"QID5","choiceId":"9"}   
     2                                                NaN   
     3                                Class/Work Schedule   
     4                                Class/Work Schedule   
     
                                                   Q12_11  \
     0  Q12. Were there any specific barriers that pre...   
     1                {"ImportId":"QID5","choiceId":"11"}   
     2                                                NaN   
     3                                                NaN   
     4                                                NaN   
     
                                                   Q12_13  \
     0  Q12. Were there any specific barriers that pre...   
     1                {"ImportId":"QID5","choiceId":"13"}   
     2                                                NaN   
     3                                                NaN   
     4                                                NaN   
     
                                                   Q12_15  \
     0  Q12. Were there any specific barriers that pre...   
     1                {"ImportId":"QID5","choiceId":"15"}   
     2                                                NaN   
     3                                                NaN   
     4                                                NaN   
     
                                                   Q12_16  \
     0  Q12. Were there any specific barriers that pre...   
     1                {"ImportId":"QID5","choiceId":"16"}   
     2                                                NaN   
     3                                                NaN   
     4                                                NaN   
     
                                                      Q13  \
     0  Q13. What events would you like to see in futu...   
     1                          {"ImportId":"QID19_TEXT"}   
     2                                                NaN   
     3                                                NaN   
     4                       Capture the flag & dodgeball   
     
                                                      Q14  \
     0  Q14. Which activities in Boston would you like...   
     1                          {"ImportId":"QID21_TEXT"}   
     2                                                NaN   
     3                                                NaN   
     4                                           Bowling    
     
                                                      Q15  
     0  Q15. If you would like to be entered for the c...  
     1                          {"ImportId":"QID26_TEXT"}  
     2                                                NaN  
     3                                                NaN  
     4                          Anthony.chukwu001@umb.edu  
     
     [5 rows x 66 columns]}



# Survey Responses by Year and Season with Trendline


```python
# Define survey summary data
survey_summary_df = pd.DataFrame({
    "Year": ['Fall 2021', 'Spring 2022', 'Fall 2022', 'Fall 2023', 'Fall 2024'],
    "Total Responses": [519, 279, 692, 148, 550]
})

# Extract data for bar chart preparation
years = ['2021', '2022', '2022', '2023', '2024']
seasons = ['Fall', 'Spring', 'Fall', 'Fall', 'Fall']
responses = survey_summary_df['Total Responses']

# UMass colors
umass_colors = {
    'Fall': '#78AFE9',  # Light Blue
    'Spring': '#005A8B'  # Dark Blue
}

# Create a figure and bar chart
fig, ax = plt.subplots(figsize=(12, 6))

# Create unique positions for bars (grouped by year)
positions = []
for i, year in enumerate(years):
    if i > 0 and years[i] == years[i-1]:
        positions.append(positions[-1] + 0.4)  # Place beside the previous bar of the same year
    else:
        positions.append(i/2)  # Leave space between different years

# Plot the bars with distinct colors for Fall and Spring
bottom = np.zeros(len(positions))  # Initialize bottom for stacking (not used here, but for consistency)
for pos, resp, year, season in zip(positions, responses, years, seasons):
    ax.bar(pos, resp, label=f"{year} {season}",
           color=umass_colors[season], width=0.35)

    # Add text on top of each bar
    ax.text(
        pos, resp + 10,  # Position slightly above the bar
        str(resp), ha='center', va='bottom', fontsize=10, color='black'
    )

# Calculate trendline points
trend_x = np.array(positions)  # Positions along x-axis
trend_y = np.array(responses)  # Corresponding y-values (top of bars)
ax.plot(trend_x, trend_y, marker="o", linestyle='--', label="Trendline", color="red")

# Adjust xticks to match bar positions
unique_years_seasons = [f"{year} {season}" for year, season in zip(years, seasons)]
ax.set_xticks(positions)
ax.set_xticklabels(unique_years_seasons, rotation=0, ha='center')
ax.set_xlabel('Year and Season', fontsize=12)
ax.set_ylabel('Number of Responses', fontsize=12)
ax.set_title('Survey Responses by Year and Season with Trendline', fontsize=14)
ax.legend(title="Survey")

# Move the legend outside the plot
ax.legend(title= "Year", bbox_to_anchor=(1.05, 1), loc='upper left', fontsize=10)

# Show the bar chart
plt.tight_layout
plt.show()
```


    
![png](output_4_0.png)
    


# Q1.Classification


```python
# Q1. Classification Data
classification_data = {
    "Year": ["Fall 2021", "Spring 2022", "Fall 2022", "Fall 2023", "Fall 2024"],
    "Freshman": [130, 75, 349, 52, 180],
    "Sophomore": [119, 73, 107, 17, 89],
    "Junior": [119, 58, 109, 40, 118],
    "Senior": [151, 73, 127, 34, 82],
    "Fifth Year": [0, 0, 0, 5, 20],
    "Six+ Year": [0, 0, 0, 0, 3],
    "Graduate Student": [0, 0, 0, 0, 53]
}

# Convert to DataFrame for easier plotting
classification_df = pd.DataFrame(classification_data)

# UMass Boston Colors
umass_colors = {
    "Freshman": "#78AFE9",
    "Sophomore": "#E9EDC8",
    "Junior": "#132245",
    "Senior": "#FEDE42",
    "Fifth Year": "#50403E",
    "Six+ Year": "#FF791F",
    "Graduate Student": "#005A8B"
}

# Create a stacked bar chart
fig, ax = plt.subplots(figsize=(16, 8))

# Plot each category as a layer in the stack
categories = ["Freshman", "Sophomore", "Junior", "Senior", "Fifth Year", "Six+ Year", "Graduate Student"]
bottom = np.zeros(len(classification_df))  # Start stacking from 0
for category in categories:
    ax.bar(
        classification_df["Year"],
        classification_df[category],
        bottom=bottom,
        label=category,
        color=umass_colors[category]
    )
    # Add text on top of each segment
    for i, value in enumerate(classification_df[category]):
        if value > 0:  # Avoid displaying zeros
            ax.text(
                i, bottom[i] + value / 2,  # Position at the center of the segment
                str(value), ha='center', va='center', fontsize=10, color='black'
            )
    bottom += classification_df[category]

# Add labels and title
ax.set_xlabel('Year', fontsize=14)
ax.set_ylabel('Number of Students', fontsize=14)
ax.set_title('Q1. Classification Over the Years (Stacked Bar Chart with Counts)', fontsize=16)

# Move the legend outside the plot
ax.legend(title="Classification", bbox_to_anchor=(1.05, 1), loc='upper left', fontsize=12)

# Display the chart
plt.tight_layout()
plt.show()
```


    
![png](output_6_0.png)
    


# Q2.International Status


```python
# Q2. Are you an International Student?

international_data = {
    "Year": ["Fall 2021", "Spring 2022", "Fall 2022", "Fall 2023", "Fall 2024"],
    "Yes": [62, 30, 67, 41, 89],
    "No": [457, 249, 625, 107, 456]
}

# Convert to DataFrame for easier plotting
international_df = pd.DataFrame(international_data)

# UMass Boston Colors for Q2
q2_colors = {
    "Yes": "#78AFE9",  # Light Blue
    "No": "#E9EDC8"  # Light Green
}

# Create a stacked bar chart with trendlines
fig, ax = plt.subplots(figsize=(16, 8))

# Initialize bottom for stacking
bottom = np.zeros(len(international_df))

# Plot each category and overlay trendlines
categories = ["Yes", "No"]
for category in categories:
    # Plot bars
    ax.bar(
        international_df["Year"],
        international_df[category],
        bottom=bottom,
        label=category,
        color=q2_colors[category]
    )
    # Add text on top of each segment
    for i, value in enumerate(international_df[category]):
        if value > 0:
            ax.text(
                i, bottom[i] + value/2,  # Position at the center
                str(value), ha='right', va='bottom', fontsize=10, color='black'
            )
    # Calculate trendline points
    trend_x = np.arange(len(international_df))  # Positions along x-axis
    trend_y = bottom + international_df[category]
    ax.plot(trend_x, trend_y,marker="o",linestyle='--', label=f"Trendline ({category})", color="red")
    bottom += international_df[category]

# Add labels and title
ax.set_xlabel('Year', fontsize=14)
ax.set_ylabel('Number of Responses', fontsize=14)
ax.set_title('Q2. Are you an International Student? (Stacked Bar Chart with Trendlines)', fontsize=16)

# Move the legend outside the plot
ax.legend(title="Response", bbox_to_anchor=(1.05, 1), loc='upper left', fontsize=12)

# Display the chart
plt.tight_layout()
plt.show()
```


    
![png](output_8_0.png)
    


# Q3.Residence


```python
# Create the residence DataFrame
residence_data = {
    "Year": ["Fall 2021", "Spring 2022", "Fall 2022", "Fall 2023", "Fall 2024"],
    "On Campus Residence Hall": [83, 43, 286, 18, 129],
    "Peninsula or Harbor Point": [0, 0, 0, 20, 82],
    "Near or behind JFK Station": [0, 0, 0, 7, 34],
    "2-5 miles from campus": [0, 0, 0, 40, 91],
    "More than 5 miles from campus": [0, 0, 0, 63, 209],
    "Off Campus (with Family)": [263, 152, 251, 0, 0],
    "Off Campus (not with Family)": [171, 80, 150, 0, 0],
    "Other": [2, 4, 5, 0, 0]
}
residence_df = pd.DataFrame(residence_data)

# Create a stacked bar chart without trendlines
fig, ax = plt.subplots(figsize=(16, 8))

# Initialize bottom for stacking
bottom = np.zeros(len(residence_df))

# Plot each category
for category in categories:
    ax.bar(
        residence_df["Year"],
        residence_df[category],
        bottom=bottom,
        label=category,
        color=umass_colors[category]
    )
    # Add text on top of each segment
    for i, value in enumerate(residence_df[category]):
        if value > 0:
            ax.text(
                i, bottom[i] + value / 2,  # Position at the center
                str(value), ha='center', va='center', fontsize=10, color='black'
            )
    bottom += residence_df[category]

# Add labels and title
ax.set_xlabel('Year', fontsize=14)
ax.set_ylabel('Number of Responses', fontsize=14)
ax.set_title('Q3. Where do you reside? (Stacked Bar Chart)', fontsize=16)

# Move the legend outside the plot
ax.legend(title="Residence", bbox_to_anchor=(1.05, 1), loc='upper left', fontsize=12)

# Display the chart
plt.tight_layout()
plt.show()
```


    
![png](output_10_0.png)
    


# Q4.Welcome Week Event Attendance:


```python
# Q4. Did you attend any Welcome Week Events? 
welcome_week_data = {
    "Year": ["Fall 2021", "Spring 2022", "Fall 2022", "Fall 2023", "Fall 2024"],
    "Yes": [308, 125, 551, 74, 347],
    "No": [211, 154, 141, 74, 199]
}

# Convert to DataFrame for easier plotting
welcome_week_df = pd.DataFrame(welcome_week_data)

# UMass Boston Colors for Q4
q4_colors = {
    "Yes": "#005A8B",  # Beacon Blue
    "No": "#E9EDC8"  # Light Green
}

# Create a stacked bar chart
fig, ax = plt.subplots(figsize=(16, 8))

# Initialize bottom for stacking
bottom = np.zeros(len(welcome_week_df))

# Plot each category
categories = ["Yes", "No"]
for category in categories:
    ax.bar(
        welcome_week_df["Year"],
        welcome_week_df[category],
        bottom=bottom,
        label=category,
        color=q4_colors[category]
    )
    # Add text on top of each segment
    for i, value in enumerate(welcome_week_df[category]):
        if value > 0:
            ax.text(
                i, bottom[i] + value / 2,  # Position at the center
                str(value), ha='center', va='center', fontsize=10, color='black'
            )
    bottom += welcome_week_df[category]

# Add labels and title
ax.set_xlabel('Year', fontsize=14)
ax.set_ylabel('Number of Responses', fontsize=14)
ax.set_title('Q4. Did you attend any Welcome Week Events? (Stacked Bar Chart)', fontsize=16)

# Move the legend outside the plot
ax.legend(title="Response", bbox_to_anchor=(1.05, 1), loc='upper left', fontsize=12)

# Display the chart
plt.tight_layout()
plt.show()
```


    
![png](output_12_0.png)
    


# Q5.Welcome Week Event Awareness:


```python
# Data consolidation for all years including Fall 2024
welcome_week_data = {
    "University Website": [84, 25, 126, 14, 16],
    "Posters": [137, 39, 282, 29, 52],
    "UMBeInvolved": [144, 69, 231, 27, 47],
    "Word of Mouth (Friends)": [112, 38, 210, 28, 25],
    "Social Media": [122, 47, 329, 31, 97],
    "RA": [0, 0, 0, 0, 21],  # New category for Fall 2024
    "Professor": [0, 0, 0, 0, 3],  # New category for Fall 2024
    "Professional Staff": [0, 0, 0, 0, 9],  # New category for Fall 2024
    "Another SAEC Event": [0, 0, 0, 0, 2],  # New category for Fall 2024
    "Walking By": [0, 0, 0, 0, 51],  # New category for Fall 2024
}

# Calculate the average responses for each category
average_responses = {method: sum(values) / len(values) for method, values in welcome_week_data.items()}

# Create a bar chart for average responses
fig, ax = plt.subplots(figsize=(12, 6))

# Sort categories by average responses for better visualization
sorted_categories = sorted(average_responses.items(), key=lambda x: x[1], reverse=True)
categories = [item[0] for item in sorted_categories]
averages = [item[1] for item in sorted_categories]

# Plot the averages
ax.bar(categories, averages, color="#78AFE9")

# Add labels to each bar
for i, avg in enumerate(averages):
    ax.text(i, avg + 1, f"{avg:.1f}", ha="center", va="bottom", fontsize=9)

# Add labels and title
ax.set_xlabel('Method of Hearing About Welcome Week', fontsize=12)
ax.set_ylabel('Average Responses', fontsize=12)
ax.set_title('Average Responses by Method of Hearing About Welcome Week Events (All Years)', fontsize=14)
plt.xticks(rotation=45, ha="right")

plt.tight_layout()
plt.show()
```


    
![png](output_14_0.png)
    


# Q6.Welcome Week Events Attended:


```python
event_data = {
    "Year": ["Fall 2021", "Spring 2022", "Fall 2022", "Fall 2023", "Fall 2024"],
    "WOWs": [69, 65, 161, 19, 55],
    "Chancellor's Welcome": [64, 0, 228, 16, 99],
    "Movie Night(s)": [42, 0, 298, 30, 115],
    "Employment Fair, Involvement Fair, and/or Volunteer Fair": [24, 0, 45, 4, 154],
    "Purchase Red Sox Tickets": [14, 0, 221, 24, 24],
    "Lawn on B": [113, 0, 240, 22, 132],
    "Chancellor's BBQ": [113, 0, 240, 22, 128],
    "SAEC's First Friday Concert": [0, 21, 99, 14, 45],
    "Campus Kickoff": [0, 17, 184, 13, 97],
    "Beacon Market Place Vendor Fair": [0, 0, 201, 20, 77],
    "Boston Lights Trip": [69, 28, 0, 5, 27],
    "SMCA Ice Cream Social": [111, 0, 0, 17, 86],
    "Other": [0, 28, 0, 4, 0],
    "Pizza Pop-Up": [0, 0, 0, 0, 79],
    "Game Room Open House": [0, 0, 0, 0, 43]
}

# Convert the event data to a DataFrame
event_df = pd.DataFrame(event_data)

# Set up UMass Boston colors for visualization
event_colors = {
    "WOWs": "#78AFE9",
    "Chancellor's Welcome": "#005A8B",
    "Movie Night(s)": "#FEDE42",
    "Employment Fair, Involvement Fair, and/or Volunteer Fair": "#FF791F",
    "Purchase Red Sox Tickets": "#E9EDC8",
    "Lawn on B": "#132245",
    "Chancellor's BBQ": "#50403E",
    "SAEC's First Friday Concert": "#005A8B",
    "Campus Kickoff": "#78AFE9",
    "Beacon Market Place Vendor Fair": "#FEDE42",
    "Boston Lights Trip": "#FF791F",
    "SMCA Ice Cream Social": "#E9EDC8",
    "Other": "#132245",
    "Pizza Pop-Up": "#FF791F",
    "Game Room Open House": "#50403E"
}

# Generate individual bar charts for each event
for event in event_df.columns[1:]:  # Loop through all event categories except 'Year'
    fig, ax = plt.subplots(figsize=(10, 6))
    
    # Plot the bar chart for the current event
    ax.bar(
        event_df["Year"],
        event_df[event],
        color=event_colors[event],
        label=event
    )
    
    # Add text on top of each bar
    for i, value in enumerate(event_df[event]):
        if value > 0:
            ax.text(
                i, value,  # Position slightly above the bar
                str(int(value)), ha='center', va='bottom', fontsize=10, color='black'
            )
    
    # Add labels, title, and legend
    ax.set_xlabel('Year', fontsize=12)
    ax.set_ylabel('Number of Responses', fontsize=12)
    ax.set_title(f'Attendance for {event} (2021-2024)', fontsize=14)
    ax.legend(title="Event", loc='best')
    
    # Display the chart
    plt.tight_layout()
    plt.show()

```


    
![png](output_16_0.png)
    



    
![png](output_16_1.png)
    



    
![png](output_16_2.png)
    



    
![png](output_16_3.png)
    



    
![png](output_16_4.png)
    



    
![png](output_16_5.png)
    



    
![png](output_16_6.png)
    



    
![png](output_16_7.png)
    



    
![png](output_16_8.png)
    



    
![png](output_16_9.png)
    



    
![png](output_16_10.png)
    



    
![png](output_16_11.png)
    



    
![png](output_16_12.png)
    



    
![png](output_16_13.png)
    



    
![png](output_16_14.png)
    


# Q7.Satisfaction and Engagement:


```python
# Define the agreement data
agreement_data = {
    "Year": ["Fall 2021", "Spring 2022", "Fall 2022", "Fall 2023", "Fall 2024"],
    "Satisfied with events attended": {
        "Strongly Agree": [135, 48, 209, 16, 113],
        "Agree": [99, 40, 237, 28, 139],
        "Neutral": [26, 14, 44, 8, 38],
        "Disagree": [10, 4, 11, 3, 4],
        "Strongly Disagree": [2, 0, 1, 1, 2],
    },
    "Had fun at events": {
        "Strongly Agree": [151, 49, 223, 21, 0],
        "Agree": [85, 43, 218, 23, 0],
        "Neutral": [29, 13, 52, 10, 0],
        "Disagree": [6, 1, 8, 1, 30],
        "Strongly Disagree": [1, 0, 1, 1, 10],
    },
    "Learned my way around campus": {
        "Strongly Agree": [140, 40, 260, 24, 76],
        "Agree": [78, 33, 147, 17, 98],
        "Neutral": [42, 25, 81, 10, 81],
        "Disagree": [11, 5, 9, 4, 30],
        "Strongly Disagree": [1, 0, 2, 1, 10],
    },
    "Discovered ways to get involved": {
        "Strongly Agree": [133, 35, 203, 19, 94],
        "Agree": [89, 40, 186, 13, 138],
        "Neutral": [38, 23, 88, 19, 47],
        "Disagree": [8, 6, 18, 3, 14],
        "Strongly Disagree": [2, 0, 3, 2, 3],
    },
    "Identified student orgs/activities": {
        "Strongly Agree": [116, 35, 174, 18, 0],
        "Agree": [89, 40, 175, 18, 0],
        "Neutral": [53, 23, 117, 15, 0],
        "Disagree": [10, 6, 31, 5, 0],
        "Strongly Disagree": [3, 0, 4, 0, 0],
    },
    "Made new friends": {
        "Strongly Agree": [86, 28, 175, 14, 64],
        "Agree": [80, 28, 149, 15, 87],
        "Neutral": [63, 31, 111, 14, 88],
        "Disagree": [32, 15, 50, 8, 38],
        "Strongly Disagree": [11, 4, 15, 5, 17],
    },
    "Developed greater sense of community": {
        "Strongly Agree": [117, 39, 198, 15, 89],
        "Agree": [94, 37, 194, 21, 132],
        "Neutral": [46, 26, 85, 11, 49],
        "Disagree": [9, 2, 17, 7, 17],
        "Strongly Disagree": [5, 2, 6, 2, 8],
    },
}

# Define colors for response categories
response_colors = {
    "Strongly Agree": "#78AFE9",
    "Agree": "#005A8B",
    "Neutral": "#FEDE42",
    "Disagree": "#FF791F",
    "Strongly Disagree": "#E9EDC8",
}

# Ensure all response arrays are of the same length as the Year array
year_length = len(agreement_data["Year"])
for statement, responses in agreement_data.items():
    if statement == "Year":
        continue
    for category, values in responses.items():
        if len(values) < year_length:
            responses[category] = values + [0] * (year_length - len(values))

# Generate separate bar charts for each statement over the years
for statement, responses in agreement_data.items():
    if statement == "Year":
        continue

    # Create a DataFrame for the current statement
    statement_df = pd.DataFrame(responses)
    statement_df["Year"] = agreement_data["Year"]

    # Create a grouped bar chart for the statement
    fig, ax = plt.subplots(figsize=(12, 8))

    # Positions for each bar group
    x = np.arange(len(statement_df["Year"]))

    # Bar width
    width = 0.15

    # Plot each response category as a group
    for i, category in enumerate(response_colors.keys()):
        ax.bar(
            x + i * width,  # Offset for each category
            statement_df[category],
            width=width,
            label=category,
            color=response_colors[category]
        )
        # Add text labels for the bars
        for j, value in enumerate(statement_df[category]):
            if value > 0:
                ax.text(
                    x[j] + i * width, value + 1,  # Position above the bar
                    str(int(value)), ha='center', va='bottom', fontsize=9
                )

    # Add labels, title, and legend
    ax.set_xlabel('Year', fontsize=12)
    ax.set_ylabel('Number of Responses', fontsize=12)
    ax.set_title(f'{statement} (2021-2024)', fontsize=14)
    ax.set_xticks(x + (len(response_colors) - 1) * width / 2)
    ax.set_xticklabels(statement_df["Year"], fontsize=10)
    ax.legend(title="Response Category", bbox_to_anchor=(1.05, 1), loc='upper left', fontsize=10)

    # Display the chart
    plt.tight_layout()
    plt.show()
```


    
![png](output_18_0.png)
    



    
![png](output_18_1.png)
    



    
![png](output_18_2.png)
    



    
![png](output_18_3.png)
    



    
![png](output_18_4.png)
    



    
![png](output_18_5.png)
    



    
![png](output_18_6.png)
    


# Q8.Overall, how would you rate Welcome Week?


```python
welcome_week_ratings = {
    "Year": ["Fall 2021", "Spring 2022", "Fall 2022", "Fall 2023", "Fall 2024"],
    "Excellent": [100,33,169,0,0],
    "Good": [98,39,208,0,0],
    "Average": [63,29,113,0,0],
    "Poor": [11,5,10,0,0],
    "Very Poor": [0,0,3,0,0]
}

# Convert to DataFrame
ratings_df = pd.DataFrame(welcome_week_ratings)

# Set up UMass Boston colors for visualization
ratings_colors = {
    "Excellent": "#78AFE9",
    "Good": "#005A8B",
    "Average": "#FEDE42",
    "Poor": "#FF791F",
    "Very Poor": "#E9EDC8"
}

# Generate a stacked bar chart for overall ratings
fig, ax = plt.subplots(figsize=(12,8))

# Initialize the bottom for stacking
bottom = np.zeros(len(ratings_df))

# Plot each rating as a layer in the stack
categories = list(ratings_colors.keys())
for category in categories:
    ax.bar(
        ratings_df["Year"],
        ratings_df[category],
        bottom=bottom,
        label=category,
        color=ratings_colors[category]
    )
    # Add text on top of each segment
    for i, value in enumerate(ratings_df[category]):
        if value > 0:
            ax.text(
                i, bottom[i] + value/2.5, 
                str(int(value)), ha='center', va= 'center', fontsize=9, color='black'
            )
    bottom += ratings_df[category]

# Add labels and title
ax.set_xlabel('Year', fontsize=12)
ax.set_ylabel('Number of Responses', fontsize=12)
ax.set_title('Overall Welcome Week Ratings (2021-2024)', fontsize=14)
ax.legend(title="Rating", bbox_to_anchor=(1.05, 1), loc='upper left', fontsize=10)

# Display the chart
plt.tight_layout()
plt.show()

```


    
![png](output_20_0.png)
    


# Q9.Accompaniment:


```python
import matplotlib.pyplot as plt
import numpy as np

# Define the data for each year
data = {
    "Fall 2021": {"By Myself": 68, "With 1-2 Friends": 145, "Small Group": 57, "Large Group": 1, "Other": 1},
    "Spring 2022": {"By Myself": 27, "With 1-2 Friends": 65, "Small Group": 11, "Large Group": 2, "Other": 1},
    "Fall 2022": {"By Myself": 101, "With 1-2 Friends": 281, "Small Group": 110, "Large Group": 7, "Other": 4},
    "Fall 2023": {"By Myself": 3, "With 1-2 Friends": 5, "Small Group": 2, "Large Group": 0, "Other": 38},
    "Fall 2024": {"By Myself": 159, "With 1-2 Friends": 203, "Small Group": 61, "Large Group": 19, "Other": 22},
}

# UMass colors
colors = {
    "By Myself": "#78AFE9",
    "With 1-2 Friends": "#005A8B",
    "Small Group": "#FEDE42",
    "Large Group": "#FF791F",
    "Other": "#E9EDC8",
}

# Plot bar charts for each year
for year, responses in data.items():
    fig, ax = plt.subplots(figsize=(10, 6))

    categories = list(responses.keys())
    values = list(responses.values())
    bar_positions = np.arange(len(categories))

    # Create bars
    bars = ax.bar(bar_positions, values, color=[colors[cat] for cat in categories])

    # Add text over each bar
    for bar, value in zip(bars, values):
        ax.text(
            bar.get_x() + bar.get_width() / 2,
            bar.get_height(),  # Position above the bar
            str(value),
            ha="center",
            va="bottom",
            fontsize=10,
        )

    # Add labels, title, and grid
    ax.set_xticks(bar_positions)
    ax.set_xticklabels(categories, rotation=0, ha="right", fontsize=10)
    ax.set_ylabel("Number of Respondents", fontsize=12)
    ax.set_title(f"Who Did You Attend Welcome Week Events With? ({year})", fontsize=14)
    ax.grid(axis="y", linestyle="--", alpha=0.7)

    plt.tight_layout()
    plt.show()
```


    
![png](output_22_0.png)
    



    
![png](output_22_1.png)
    



    
![png](output_22_2.png)
    



    
![png](output_22_3.png)
    



    
![png](output_22_4.png)
    


### FOLLOW UP 
1. FALL 2021 : Q16. Events during welcome week provided you with an opportunity to form meaningful connection with other students.
2. SPRING 2022: Same as above
3. FALL 2022: Same as above 4. FALL 2024 : If you attended with friends, how did you meet your group of friends? - Selected Choice

# Q10.Future Event Suggestions:


```python
import matplotlib.pyplot as plt

# Data: Keywords and their counts for each year
data = {
    "Event Suggestion": [
        "Large Scale Concert", "Food Trucks", "Social Events", "Paint Nights", 
        "Movie Nights", "Game Shows", "Comedian", "Board Game Events", 
        "Dances", "Escape Room", "Trivia Nights"
    ],
    "Fall 2022": [276, 435, 272, 299, 232, 234, 205, 190, 212, 0, 0],
    "Fall 2023": [29, 44, 33, 34, 27, 27, 22, 24, 21, 0, 0],
    "Fall 2024": [7, 9, 7, 6, 5, 5, 0, 0, 0, 1, 1],
}

# Prepare data for plotting
categories = data["Event Suggestion"]
years = ["Fall 2022", "Fall 2023", "Fall 2024"]
frequencies = [data[year] for year in years]

# Flatten the data for scatter plot
x_positions = []
y_positions = []
bubble_sizes = []
labels = []

# Assign x and y positions, bubble sizes
for i, year in enumerate(years):
    for j, suggestion in enumerate(categories):
        x_positions.append(i + 1)  # Year position on x-axis
        y_positions.append(j + 1)  # Suggestion position on y-axis
        bubble_sizes.append(frequencies[i][j] * 10)  # Scale bubble size
        labels.append(f"{suggestion} ({year}): {frequencies[i][j]}")  # Tooltip

# Create the bubble chart
fig, ax = plt.subplots(figsize=(12, 8))

# Scatter plot with bubble sizes
scatter = ax.scatter(
    x_positions, y_positions, s=bubble_sizes, c=bubble_sizes, cmap="cool", alpha=0.6, edgecolors="w", linewidth=0.5
)

# Add labels for y-axis
ax.set_yticks(range(1, len(categories) + 1))
ax.set_yticklabels(categories, fontsize=10)
ax.set_xticks(range(1, len(years) + 1))
ax.set_xticklabels(years, fontsize=12)
ax.set_xlabel("Year", fontsize=14)
ax.set_ylabel("Event Suggestions", fontsize=14)
ax.set_title("Bubble Chart of Event Suggestions (Fall 2022-2024)", fontsize=16)

# Add labels inside bubbles (optional)
for x, y, size, label in zip(x_positions, y_positions, bubble_sizes, labels):
    if size > 0:
        ax.text(x, y, str(size // 10), ha="center", va="center", fontsize=8, color="black")

# Display legend and colorbar
cbar = plt.colorbar(scatter, ax=ax, orientation="vertical")
cbar.set_label("Number of Mentions", fontsize=12)

plt.tight_layout()
plt.show()
```


    
![png](output_25_0.png)
    



```python
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

# Data: Combined keyword frequencies across years
keywords_data = {
    "Keyword": ["Food Trucks", "Movie Night", "Game Night", "Paint Nights", "Concerts", "Social Events", "Trivia", "Board Games", "Outdoor Events", "Talent Shows", "Cultural Exchange", "Escape Room"],
    "Fall 2021": [15, 10, 7, 5, 8, 12, 6, 4, 5, 3, 0, 0],
    "Spring 2022": [8, 7, 9, 6, 5, 7, 3, 2, 4, 2, 0, 0],
    "Fall 2022": [20, 27, 34, 42, 29, 33, 27, 24, 30, 23, 0, 0],
    "Fall 2023": [12, 27, 21, 34, 29, 33, 27, 24, 30, 23, 0, 0],
    "Fall 2024": [9, 15, 12, 25, 19, 20, 17, 18, 22, 15, 8, 6]
}

# Convert to DataFrame
df = pd.DataFrame(keywords_data)

# Prepare data for the bubble chart
years = ["Fall 2021", "Spring 2022", "Fall 2022", "Fall 2023", "Fall 2024"]
x = []  # x-coordinates (Years)
y = []  # y-coordinates (Keywords)
sizes = []  # Bubble sizes
colors = []  # Assign colors to each year
counts = []  # Frequencies to display on bubbles

color_map = {
    "Fall 2021": "#78AFE9",
    "Spring 2022": "#FEDE42",
    "Fall 2022": "#005A8B",
    "Fall 2023": "#FF791F",
    "Fall 2024": "#E9EDC8"
}

for i, year in enumerate(years):
    for j, keyword in enumerate(df["Keyword"]):
        x.append(i)  # Year index
        y.append(j)  # Keyword index
        sizes.append(df[year][j] * 10)  # Scale size
        colors.append(color_map[year])
        counts.append(df[year][j])  # Store the count

# Create bubble chart
fig, ax = plt.subplots(figsize=(12, 8))

scatter = ax.scatter(x, y, s=sizes, c=colors, alpha=0.6, edgecolors="w")

# Add counts as labels to each bubble
for i, count in enumerate(counts):
    if count > 0:  # Only display non-zero counts
        ax.text(x[i], y[i], str(count), fontsize=8, ha='center', va='center', color='black')

# Adjust axis
ax.set_xticks(range(len(years)))
ax.set_xticklabels(years, fontsize=10)
ax.set_yticks(range(len(df["Keyword"])))
ax.set_yticklabels(df["Keyword"], fontsize=10)
ax.set_xlabel("Year", fontsize=12)
ax.set_ylabel("Keywords", fontsize=12)
ax.set_title("Keyword Popularity Across Welcome Week Events (2021-2024)", fontsize=14)

# Add legend
handles = [plt.Line2D([0], [0], marker='o', color='w', label=year, markersize=10, markerfacecolor=color) for year, color in color_map.items()]
ax.legend(handles=handles, title="Years", bbox_to_anchor=(1.05, 1), loc='upper left')

plt.tight_layout()
plt.show()
```


    
![png](output_26_0.png)
    


# Q11.Reasons for Non-attendance:


```python
import matplotlib.pyplot as plt
import numpy as np

# Data for reasons of non-attendance
years_data = {
    "Fall 2021": {
        "Didn't know about Welcome Week": 96,
        "Didn't have time to attend": 61,
        "Wasn't on campus that week": 19,
        "Didn't have anyone to go with": 15,
        "Other": 10
    },
    "Spring 2022": {
        "Didn't know about Welcome Week": 69,
        "Didn't have time to attend": 46,
        "Wasn't on campus that week": 8,
        "Didn't have anyone to go with": 13,
        "Other": 4
    },
    "Fall 2022": {
        "Didn't know about Welcome Week": 31,
        "Didn't have time to attend": 66,
        "Wasn't on campus that week": 19,
        "Didn't have anyone to go with": 12,
        "Other": 5
    },
    "Fall 2023": {
        "Child Care": 7,
        "Transportation": 46,
        "Financial": 13,
        "Class/Work Schedule": 90,
        "Weather": 10,
        "Other": 14
    },
    "Fall 2024": {
        "Child Care": 11,
        "Transportation": 95,
        "Financial": 39,
        "Class/Work Schedule": 320,
        "Weather": 30,
        "Lack of Interest": 101,
        "Did not want to attend alone": 150,
        "Other": 37
    }
}

# UMass color palette
umass_colors = [
    "#13294B", "#005A8B", "#78AFE9", "#FFC72C", "#FF791F",
    "#E9EDC8", "#F4E285", "#BE4D00"
]

# Create separate horizontal bar charts for each year
for year, data in years_data.items():
    categories = list(data.keys())
    counts = list(data.values())
    
    # Create horizontal bar chart
    fig, ax = plt.subplots(figsize=(10, 6))
    bars = ax.barh(categories, counts, color=umass_colors[:len(categories)])
    
    # Add count labels to the right of the bars
    for bar in bars:
        width = bar.get_width()
        ax.text(
            width, bar.get_y() + bar.get_height() / 2,  # Position to the right of the bar
            str(int(width)),
            va='center', fontsize=10
        )
    
    # Title and labels
    ax.set_title(f"Reasons for Non-Attendance - {year}", fontsize=14)
    ax.set_xlabel("Number of Responses", fontsize=12)
    ax.set_ylabel("Reasons", fontsize=12)
    
    # Adjust layout and display chart
    plt.tight_layout()
    plt.show()
```


    
![png](output_28_0.png)
    



    
![png](output_28_1.png)
    



    
![png](output_28_2.png)
    



    
![png](output_28_3.png)
    



    
![png](output_28_4.png)
    


# Q12.Event Communication:


```python
# Data preparation
communication_data = {
    "Year": ["Fall 2021", "Spring 2022", "Fall 2022"],
    "University Website": [25, 5, 12],
    "Posters": [43, 22, 86],
    "UMBeInvolved": [36, 13, 36],
    "Social Media": [74, 51, 223],
    "Email": [291, 150, 271],
}

df = pd.DataFrame(communication_data)

# Plotting a stacked bar chart
fig, ax = plt.subplots(figsize=(10, 7))

categories = ["University Website", "Posters", "UMBeInvolved", "Social Media", "Email"]
colors = ["#005A8B", "#78AFE9", "#FEDE42", "#FF791F", "#132245"]  # UMass color palette

bottom = [0] * len(df)  # Initialize bottom for stacking

# Create stacked bars
for category, color in zip(categories, colors):
    ax.bar(
        df["Year"],
        df[category],
        bottom=bottom,
        label=category,
        color=color,
    )
    # Add labels for each segment
    for i, value in enumerate(df[category]):
        if value > 0:
            ax.text(
                i, bottom[i] + value/2,  # Position the label at the center of the bar segment
                str(value),
                ha="center",
                va="center",
                fontsize=9,
                color="white" if value > 50 else "black",  # Contrast text color based on segment size
            )
    bottom += df[category]  # Update bottom for the next category

# Adding labels and title
ax.set_title("Preferred Communication Methods for Event Information (2021-2022)", fontsize=16)
ax.set_xlabel("Year", fontsize=12)
ax.set_ylabel("Number of Respondents", fontsize=12)
ax.legend(title="Communication Methods", bbox_to_anchor=(1.05, 1), loc='upper left', fontsize=10)

# Display the plot
plt.tight_layout()
plt.show()

```


    
![png](output_30_0.png)
    


# Q13.Availability:


```python
# DAYS AVAILIBILITY
availability_all_years  = {
    'Fall 2021':{
    "Day": ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
    "9am - 12pm": [92, 81, 87, 74, 101],
    "12pm - 3pm": [171, 132, 171, 148, 173],
    "3pm - 6pm": [210, 202, 202, 205, 212],
    "6pm - 9pm": [161, 164, 156, 159, 165]
},
    "Spring 2022": {
        "Day": ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
        "9am - 12pm": [52, 54, 61, 51, 60],
        "12pm - 3pm": [84, 84, 91, 82, 88],
        "3pm - 6pm": [113, 110, 124, 106, 123],
        "6pm - 9pm": [73, 73, 76, 77, 84]
    },
    "Fall 2022": {
        "Day": ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
        "9am - 12pm": [95, 102, 97, 97, 102],
        "12pm - 3pm": [193, 188, 189, 183, 216],
        "3pm - 6pm": [306, 282, 277, 283, 334],
        "6pm - 9pm": [321, 312, 322, 328, 349]
    },
    "Fall 2023": {
        "Time Slot": ["8am - 11am", "11am - 2pm", "2pm - 5pm", "5pm - 8pm", "8pm - Midnight"],
        "Responses": [8, 30, 36, 36, 15]
    }
}

# data N/A for Fall 2024

# Define colors for the time slots
time_slot_colors = {
    "9am - 12pm": "#78AFE9",
    "12pm - 3pm": "#005A8B",
    "3pm - 6pm": "#FEDE42",
    "6pm - 9pm": "#FF791F",
    "8am - 11am": "#78AFE9",
    "11am - 2pm": "#005A8B",
    "2pm - 5pm": "#FEDE42",
    "5pm - 8pm": "#FF791F",
    "8pm - Midnight": "#E9EDC8"
}

# Generate grouped bar charts for Spring 2022 and Fall 2022
for year, data in availability_all_years.items():
    if year == "Fall 2023":  # Special handling for Fall 2023
        continue
    
    availability_df = pd.DataFrame(data)
    fig, ax = plt.subplots(figsize=(14, 8))
    bar_width = 0.2  # Width of each bar
    positions = np.arange(len(availability_df["Day"]))  # Positions for each day

    # Plot each time slot as a separate group
    offset = -bar_width * 1.5  # Center the groups around the days
    for time_slot in ["9am - 12pm", "12pm - 3pm", "3pm - 6pm", "6pm - 9pm"]:
        ax.bar(
            positions + offset,
            availability_df[time_slot],
            bar_width,
            label=time_slot,
            color=time_slot_colors[time_slot]
        )
        # Add labels closer to each bar
        for i, value in enumerate(availability_df[time_slot]):
            if value > 0:
                ax.text(
                    i + offset, value,  # Slightly above the bar but closer
                    str(int(value)), ha="center", va="bottom", fontsize=9
                )
        offset += bar_width

    # Add labels, title, and legend
    ax.set_xlabel('Day of the Week', fontsize=12)
    ax.set_ylabel('Number of Responses', fontsize=12)
    ax.set_title(f'Availability by Time Slot ({year})', fontsize=14)
    ax.set_xticks(positions)
    ax.set_xticklabels(availability_df["Day"], rotation=0, ha="center")
    ax.legend(title="Time Slot", fontsize=10)

    # Adjust layout and display the chart
    plt.tight_layout()
    plt.show()

# Special grouped bar chart for Fall 2023
fall_2023_df = pd.DataFrame(availability_all_years["Fall 2023"])
fig, ax = plt.subplots(figsize=(12, 6))
ax.bar(
    fall_2023_df["Time Slot"],
    fall_2023_df["Responses"],
    color=[time_slot_colors[slot] for slot in fall_2023_df["Time Slot"]],
    label="Responses"
)
# Add labels closer to the bars
for i, value in enumerate(fall_2023_df["Responses"]):
    ax.text(i, value + 0.5, str(int(value)), ha="center", va="bottom", fontsize=9)

# Add labels and title
ax.set_xlabel('Time Slot', fontsize=12)
ax.set_ylabel('Number of Responses', fontsize=12)
ax.set_title('Availability by Time Slot (Fall 2023)', fontsize=14)

# Adjust layout and display the chart
plt.tight_layout()
plt.show()
```


    
![png](output_32_0.png)
    



    
![png](output_32_1.png)
    



    
![png](output_32_2.png)
    



    
![png](output_32_3.png)
    



```python
# Average Time 2021-2024
# Consolidate historical data for averages across all years (excluding Fall 2024 which is N/A)
historical_data = {
    "9am - 12pm": [92, 81, 87, 74, 101, 52, 54, 61, 51, 60, 95, 102, 97, 97, 102],
    "12pm - 3pm": [171, 132, 171, 148, 173, 84, 84, 91, 82, 88, 193, 188, 189, 183, 216],
    "3pm - 6pm": [210, 202, 202, 205, 212, 113, 110, 124, 106, 123, 306, 282, 277, 283, 334],
    "6pm - 9pm": [161, 164, 156, 159, 165, 73, 73, 76, 77, 84, 321, 312, 322, 328, 349]
}

# Calculate averages for each time slot
average_responses = {slot: sum(values) / len(values) for slot, values in historical_data.items()}

# Create a bar chart for average responses
fig, ax = plt.subplots(figsize=(10, 6))

# Plot the averages
time_slots = list(average_responses.keys())
averages = list(average_responses.values())
ax.bar(time_slots, averages, color=[time_slot_colors[slot] for slot in time_slots])

# Add labels to each bar
for i, avg in enumerate(averages):
    ax.text(i, avg + 2, f"{avg:.1f}", ha="center", va="bottom", fontsize=9)

# Add labels, title, and adjust layout
ax.set_xlabel('Time Slot', fontsize=12)
ax.set_ylabel('Average Number of Responses', fontsize=12)
ax.set_title('Average Responses by Time Slot (All Years)', fontsize=14)
plt.tight_layout()
plt.show()

```


    
![png](output_33_0.png)
    



```python
# Average days 2021-2024
# Historical data consolidated for each day across all years (excluding Fall 2024 which is N/A)
day_wanted_data = {
    "Monday": [92 + 171 + 210 + 161, 52 + 84 + 113 + 73, 95 + 193 + 306 + 321],
    "Tuesday": [81 + 132 + 202 + 164, 54 + 84 + 110 + 73, 102 + 188 + 282 + 312],
    "Wednesday": [87 + 171 + 202 + 156, 61 + 91 + 124 + 76, 97 + 189 + 277 + 322],
    "Thursday": [74 + 148 + 205 + 159, 51 + 82 + 106 + 77, 97 + 183 + 283 + 328],
    "Friday": [101 + 173 + 212 + 165, 60 + 88 + 123 + 84, 102 + 216 + 334 + 349],
}

# Calculate the total responses for each day
total_responses_per_day = {day: sum(values) for day, values in day_wanted_data.items()}

# Find the most wanted day
most_wanted_day = max(total_responses_per_day, key=total_responses_per_day.get)

# Create a bar chart for total responses by day
fig, ax = plt.subplots(figsize=(10, 6))

# Plot total responses for each day
days = list(total_responses_per_day.keys())
totals = list(total_responses_per_day.values())
ax.bar(days, totals, color=["#78AFE9", "#005A8B", "#FEDE42", "#FF791F", "#E9EDC8"])

# Add labels to each bar
for i, total in enumerate(totals):
    ax.text(i, total + 10, str(total), ha="center", va="bottom", fontsize=9)

# Add labels, title, and highlight the most wanted day
ax.set_xlabel('Day of the Week', fontsize=12)
ax.set_ylabel('Total Responses', fontsize=12)
ax.set_title('Total Responses by Day (Most Wanted Day Highlighted)', fontsize=14)

# Highlight the most wanted day
ax.bar(most_wanted_day, total_responses_per_day[most_wanted_day], color="#132245", label=f"Most Wanted Day: {most_wanted_day}")
ax.legend(fontsize=10)

plt.tight_layout()
plt.show()

# Display the most wanted day
most_wanted_day
```


    
![png](output_34_0.png)
    





    'Friday'




```python
# PnC of possible time slots to set up events : 

# Consolidated data for time slots and days across all years (excluding Fall 2024 which is N/A)
time_slot_day_data = {
    "9am - 12pm": {
        "Monday": 92 + 52 + 95,
        "Tuesday": 81 + 54 + 102,
        "Wednesday": 87 + 61 + 97,
        "Thursday": 74 + 51 + 97,
        "Friday": 101 + 60 + 102,
    },
    "12pm - 3pm": {
        "Monday": 171 + 84 + 193,
        "Tuesday": 132 + 84 + 188,
        "Wednesday": 171 + 91 + 189,
        "Thursday": 148 + 82 + 183,
        "Friday": 173 + 88 + 216,
    },
    "3pm - 6pm": {
        "Monday": 210 + 113 + 306,
        "Tuesday": 202 + 110 + 282,
        "Wednesday": 202 + 124 + 277,
        "Thursday": 205 + 106 + 283,
        "Friday": 212 + 123 + 334,
    },
    "6pm - 9pm": {
        "Monday": 161 + 73 + 321,
        "Tuesday": 164 + 73 + 312,
        "Wednesday": 156 + 76 + 322,
        "Thursday": 159 + 77 + 328,
        "Friday": 165 + 84 + 349,
    },
}

# Calculate the most effective combinations of time slots and days for setting up events
most_effective_combinations = []
for time_slot, days in time_slot_day_data.items():
    best_day = max(days, key=days.get)
    most_effective_combinations.append((time_slot, best_day, days[best_day]))

# Create a bar chart for the most effective combinations
fig, ax = plt.subplots(figsize=(12, 6))

# Prepare data for plotting
time_slots = [combo[0] for combo in most_effective_combinations]
days = [combo[1] for combo in most_effective_combinations]
counts = [combo[2] for combo in most_effective_combinations]

# Plot the bars
colors = ["#78AFE9", "#005A8B", "#FEDE42", "#FF791F", "#E9EDC8"]
ax.bar(time_slots, counts, color=colors)

# Add labels to each bar
for i, count in enumerate(counts):
    ax.text(i, count + 10, f"{days[i]}: {count}", ha="center", va="bottom", fontsize=9)

# Add labels and title
ax.set_xlabel('Time Slot', fontsize=12)
ax.set_ylabel('Total Responses', fontsize=12)
ax.set_title('Most Effective Combinations of Time Slots and Days', fontsize=14)

plt.tight_layout()
plt.show()

# Display the most effective combinations
most_effective_combinations

```


    
![png](output_35_0.png)
    





    [('9am - 12pm', 'Friday', 263),
     ('12pm - 3pm', 'Friday', 477),
     ('3pm - 6pm', 'Friday', 669),
     ('6pm - 9pm', 'Friday', 598)]



# Q14.Ticket Purchase:


```python

import pandas as pd
import matplotlib.pyplot as plt

# Aggregated data based on ticket preferences across the years
ticket_data = {
    "Year": ["Fall 2021", "Spring 2022", "Fall 2022", "Fall 2023", "Fall 2024"],
    "Sports": [50, 60, 85, 70, 75],  # Aggregated counts for Sports-related tickets
    "Concerts": [45, 55, 90, 80, 85],  # Concerts and music events
    "Broadway/Theatre": [30, 35, 50, 45, 55],  # Broadway and theatrical shows
    "Museums": [25, 30, 40, 35, 45],  # Museum and cultural venues
    "Recreation": [20, 25, 35, 30, 40],  # Recreational activities
}

# Convert to DataFrame
ticket_df = pd.DataFrame(ticket_data)

# Plotting a stacked bar chart with UMASS-compliant colors
fig, ax = plt.subplots(figsize=(12, 8))

categories = ["Sports", "Concerts", "Broadway/Theatre", "Museums", "Recreation"]
colors = ["#005A8B", "#78AFE9", "#FEDE42", "#FF791F", "#132245"]  # UMASS colors

bottom = [0] * len(ticket_df)  # Initialize bottom for stacking

# Plot each category as a stacked layer
for category, color in zip(categories, colors):
    ax.bar(
        ticket_df["Year"],
        ticket_df[category],
        bottom=bottom,
        label=category,
        color=color,
    )
    # Adding count labels
    for i, value in enumerate(ticket_df[category]):
        ax.text(
            i, bottom[i] + value / 2, str(value), ha="center", va="center", fontsize=10, color="white"
        )
    bottom = [b + v for b, v in zip(bottom, ticket_df[category])]

# Adding labels and title
ax.set_title("Ticket Preferences by Category (2021–2024)", fontsize=16)
ax.set_xlabel("Year", fontsize=12)
ax.set_ylabel("Number of Mentions", fontsize=12)
ax.legend(title="Ticket Categories", bbox_to_anchor=(1.05, 1), loc="upper left", fontsize=10)

# Display the plot
plt.tight_layout()
plt.show()
```


    
![png](output_37_0.png)
    


1. Sports Tickets:
- Boston Celtics
- New England Patriots
- Boston Bruins
- Red Sox
- Some also requested tickets for other sports like soccer and NFL games.

2. Concerts and Musical Events:
- Concert tickets are consistently among the top choices.
- Specific mentions include local bands, Boston Symphony Orchestra, and famous artists.

3. Broadway, Theatre, and Musicals:
- Requests for Broadway shows and local theatrical performances such as "The Nutcracker."

4. Museums and Cultural Experiences:
- Museum of Fine Arts (MFA)
- Isabella Stewart Gardner Museum
- Museum of Science
- Franklin Park Zoo
- Boston Lights at the Zoo.

5. Recreational Activities:
- Bowling
- Go-Karting
- Ice Skating
- Laser Tag
- Escape Rooms.

6. Amusement Parks and Day Trips:
- Six Flags
- Skiing trips
- Boston Duck Tours
- Trips to New York City.
  
### Emerging and Unique Requests:
Seasonal activities like haunted houses and fairs (e.g., Topsfield Fair).
Discounts for local restaurants or coupons for Boston-area small businesses.
Stand-up comedy shows and drag performances.
Dance/fitness classes at local studios.
### Trends by Year:
Fall 2021: Social media awareness and general activities like sports, concerts, and museums were prominent.
Spring 2022: Slightly niche interests emerged like KPOP concerts and escape rooms.
Fall 2022: Requests shifted towards broader categories like art museums and more immersive experiences.
Fall 2023: Greater focus on theatre, dance, and musical events alongside traditional sports.
Fall 2024: Balanced interest in sports, concerts, cultural activities, and general recreation.


```python

```


```python

```
